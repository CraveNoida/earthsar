/* =====================================================================
   EARTHSAR WEBSITE CONTENT
   Edit this file to update the website. No other code changes needed.
   Only add genuine, verifiable information.
   ===================================================================== */
window.EARTHSAR_CONFIG = {

  /* ---------- Statistics ----------
     Leave a value empty ("") to show "XX" as a placeholder. */
  stats: {
    years: "",          // e.g. "12"   -> Years of Experience
    clients: "",        // e.g. "1500" -> Clients Assisted
    associations: "",   // e.g. "25"   -> Industry Associations
    satisfaction: ""    // e.g. "98"   -> Client Satisfaction (%)
  },

  /* ---------- Contact details ---------- */
  contact: {
    phone: "",          // e.g. "+91 98XXX XXXXX"
    email: "",          // e.g. "hello@earthsar.com"
    address: "",        // e.g. "Office address, Ghaziabad, Uttar Pradesh"
    hours: ""           // e.g. "Mon–Sat, 10:00 am – 7:00 pm"
  },

  /* ---------- Forms ----------
     The website is static, so form submissions are sent to a form service.
     1. Create a free form at https://formspree.io (or a similar service).
     2. Paste its endpoint URL below, e.g. "https://formspree.io/f/abcdwxyz".
     Enquiries and review submissions will then arrive in your inbox.
     You can use the same endpoint for both. */
  forms: {
    enquiryEndpoint: "",
    reviewEndpoint: ""
  },

  /* ---------- Hero image ----------
     Leave empty to use the built-in architectural illustration,
     or set a path such as "images/hero.jpg" (portrait photo works best). */
  heroImage: "",
  heroImageAlt: "Earthsar advisors in a client meeting",

  /* ---------- Associations (partner logos) ----------
     Order here = order on the website. Put logo files in /images.
     { name: "Company Name", website: "https://...", logo: "images/partner.png" } */
  partners: [
  ],

  /* ---------- Credentials / achievements ----------
     type: "Registration" | "Certification" | "Membership" | "Award" | "Recognition"
     { type: "Registration", title: "UP RERA Registration", issuer: "UP RERA",
       year: "2024", reference: "Registration number", description: "..." } */
  credentials: [
  ],

  /* ---------- Team ----------
     { name: "Full Name", role: "Designation", experience: "12 years in real-estate advisory",
       bio: "Short introduction.", linkedin: "https://linkedin.com/in/...", photo: "images/name.jpg" } */
  team: [
  ],

  /* ---------- Published client reviews ----------
     Add reviews here after confirming them. Newest first is not required; they are sorted by date.
     { name: "Client Name", rating: 5, date: "2026-09-01", verified: true,
       message: "Review text", photo: "images/reviews/client.jpg",
       photos: ["images/reviews/p1.jpg"], videoUrl: "https://youtu.be/..." } */
  reviews: [
  ],

  /* ---------- Legal pages ----------
     Set to page URLs once your legal text is ready, e.g. "privacy.html". */
  legal: {
    privacy: "",
    terms: "",
    disclaimer: ""
  }
};
